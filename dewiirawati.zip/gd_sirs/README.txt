
NAMA KELOMPOK: 

-DEWI IRAWATI_163110028
-RAHMI NANDA KP_163110021
-MARIANA ELDA _173110029



1. LOGIN : 
USERNAME: dewi
PASSWORD: dewi

2.) buat database bernama gd_sirs

3.) Import database di folder db->gd_sirs.sql

4.) xampp versi v3.2.2


