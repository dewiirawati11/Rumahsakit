<div id="footer">
      <p>&copy;  DEWI IRAWATI - <?php echo date("Y");?> All Right Reserved </p>
</div>